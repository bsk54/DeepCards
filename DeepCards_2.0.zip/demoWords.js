// demoWords.js

export const demoWords = {
  // Latin‑script languages (no romanization needed)
  'en-US': {
    words: ['water','sky','moon','sun','life','man','woman','earth','fire','star']
  },
  'es-ES': {
    words: ['agua','cielo','luna','sol','vida','hombre','mujer','tierra','fuego','estrella']
  },
  'fr-FR': {
    words: ['eau','ciel','lune','soleil','vie','homme','femme','terre','feu','étoile']
  },
  'de-DE': {
    words: ['Wasser','Himmel','Mond','Sonne','Leben','Mann','Frau','Erde','Feuer','Stern']
  },
  'it-IT': {
    words: ['acqua','cielo','luna','sole','vita','uomo','donna','terra','fuoco','stella']
  },
  'pt-PT': {
    words: ['água','céu','lua','sol','vida','homem','mulher','terra','fogo','estrela']
  },
  'pt-BR': {
    words: ['água','céu','lua','sol','vida','homem','mulher','terra','fogo','estrela']
  },
  'nl-NL': {
    words: ['water','lucht','maan','zon','leven','man','vrouw','aarde','vuur','ster']
  },
  'pl-PL': {
    words: ['woda','niebo','księżyc','słońce','życie','mężczyzna','kobieta','ziemia','ogień','gwiazda']
  },
  'sw-KE': {
    words: ['maji','anga','mwezi','jua','maisha','mwanaume','mwanamke','dunia','moto','nyota']
  },
  'id-ID': {
    words: ['air','langit','bulan','matahari','kehidupan','pria','wanita','bumi','api','bintang']
  },
  'tl-PH': {
    words: ['tubig','langit','buwan','araw','buhay','lalaki','babae','lupa','apoy','bituin']
  },
  'tr-TR': {
    words: ['su','gökyüzü','ay','güneş','yaşam','erkek','kadın','dünya','ateş','yıldız']
  },
  'vi-VN': {
    words: ['nước','bầu trời','mặt trăng','mặt trời','cuộc sống','đàn ông','đàn bà','trái đất','lửa','ngôi sao']
  },

  // non‑Latin scripts (include romanization)
  'zh-CN': {
    words: ['水','天','月','日','生','男','女','地','火','星'],
    roman: ['shuǐ','tiān','yuè','rì','shēng','nán','nǚ','dì','huǒ','xīng']
  },
  'ja-JP': {
    words: ['みず','そら','つき','たいよう','いのち','おとこ','おんな','ちきゅう','ひ','ほし'],
    roman: ['mizu','sora','tsuki','taiyō','inochi','otoko','onna','chikyū','hi','hoshi']
  },
  'ko-KR': {
    words: ['물','하늘','달','태양','생명','남자','여자','지구','불','별'],
    roman: ['mul','haneul','dal','taeyang','saengmyeong','namja','yeoja','jigu','bul','byeol']
  },
  'ru-RU': {
    words: ['вода','небо','луна','солнце','жизнь','мужчина','женщина','земля','огонь','звезда'],
    roman: ['voda','nebo','luna','solntse','zhiznʼ','muzhchina','zhenshchina','zemlya','ogonʼ','zvezda']
  },
  'ar-EG': {
    words: ['ماء','سماء','قمر','شمس','حياة','رجل','امرأة','أرض','نار','نجم'],
    roman: ['māʼ','samāʼ','qamar','shams','ḥayāh','rajul','imraʼah','arḍ','nār','najm']
  },
  'fa-IR': {
    words: ['آب','آسمان','ماه','خورشید','زندگی','مرد','زن','زمین','آتش','ستاره'],
    roman: ['âb','âsemân','mâh','khorshīd','zendegī','mard','zan','zamīn','âtash','setāreh']
  },
  'hi-IN': {
    words: ['पानी','आसमान','चाँद','सूरज','जीवन','आदमी','औरत','धरती','आग','तारा'],
    roman: ['pānī','āsmān','chā̃d','sūraj','jīvan','ādmī','aurat','dhartī','āg','tārā']
  },
  'bn-BD': {
    words: ['পানি','আকাশ','চাঁদ','সূর্য','জীবন','পুরুষ','মহিলা','পৃথিবী','আগুন','তারা'],
    roman: ['pāni','ākāś','chā̃d','sūrya','jīban','puruṣ','mahilā','pr̥thibī','āgun','tārā']
  },
  'ur-PK': {
    words: ['پانی','آسمان','چاند','سورج','زندگی','مرد','عورت','زمین','آگ','ستارہ'],
    roman: ['pānī','āsmān','chā̃d','sūraj','zindagī','mard','aurat','zamīn','āg','sitārah']
  }
};
